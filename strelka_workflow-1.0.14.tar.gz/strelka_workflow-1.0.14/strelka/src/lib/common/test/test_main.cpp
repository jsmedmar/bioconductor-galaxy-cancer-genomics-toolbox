// -*- mode: c++; indent-tabs-mode: nil; -*-
//
// Copyright (c) 2009-2013 Illumina, Inc.
//
// This software is provided under the terms and conditions of the
// Illumina Open Source Software License 1.
//
// You should have received a copy of the Illumina Open Source
// Software License 1 along with this program. If not, see
// <https://github.com/sequencing/licenses/>
//

#define BOOST_TEST_MODULE libcommon
#include "boost/test/unit_test.hpp"

// placeholder until we can create real tests for this library:
BOOST_AUTO_TEST_CASE( test_placeholder ) {
    BOOST_CHECK_EQUAL(1,1);
}

