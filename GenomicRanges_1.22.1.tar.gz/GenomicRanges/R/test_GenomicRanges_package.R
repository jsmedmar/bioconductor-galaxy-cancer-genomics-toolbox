.test <- function() BiocGenerics:::testPackage("GenomicRanges")
